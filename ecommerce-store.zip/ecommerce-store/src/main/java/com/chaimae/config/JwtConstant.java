package com.chaimae.config;

public class JwtConstant {
	
	public static final String SECRET_KEY ="chahfhfdhfdimadjkdsjlksppsqodjhhcbdte";
	public static final String JWT_HEADER="AUTHORIZATON";

}
