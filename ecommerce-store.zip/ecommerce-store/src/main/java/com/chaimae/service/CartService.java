package com.chaimae.service;

import com.chaimae.exception.ProductException;
import com.chaimae.model.Cart;
import com.chaimae.model.User;
import com.chaimae.request.AddItemRequest;

public interface CartService {

	public Cart createCart(User user);
	
	public String addCartItem(Long userId, AddItemRequest req) throws ProductException;
	
	public Cart findUserCart(Long userId);
}
