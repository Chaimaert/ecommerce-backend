package com.chaimae.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.chaimae.exception.OrderException;
import com.chaimae.model.Address;
import com.chaimae.model.Cart;
import com.chaimae.model.CartItem;
import com.chaimae.model.Order;
import com.chaimae.model.OrderItem;
import com.chaimae.model.User;
import com.chaimae.repository.AddressRepository;
import com.chaimae.repository.CartRepository;
import com.chaimae.repository.OrderItemRepository;
import com.chaimae.repository.OrderRepository;
import com.chaimae.repository.UserRepository;

@Service
public class OrderServiceImplementation implements OrderService{
	
	private OrderRepository orderRepository;
	private CartService cartService;
	private AddressRepository addressRepository;
	private UserRepository userRepository;
	private OrderItemService orderItemService;
	private OrderItemRepository orderItemRepository;

	
	public OrderServiceImplementation(OrderRepository orderRepository,
			CartService cartService,
			AddressRepository addressRepository,
			UserRepository userRepository,
			OrderItemService orderItemService,
			OrderItemRepository orderItemRepository) {
		
		this.orderRepository = orderRepository;
		this.cartService = cartService;
		this.addressRepository = addressRepository;
		this.userRepository = userRepository;
		this.orderItemService = orderItemService;
		this.orderRepository = orderRepository;

	}

	@Override
	public Order createOrder(User user, Address shippAddress) {

		shippAddress.setUser(user);
		Address address = addressRepository.save(shippAddress);
		user.getAddress().add(address);
		userRepository.save(user);
		
		Cart cart = cartService.findUserCart(user.getId());
		List<OrderItem> orderItems = new ArrayList<>();
		
		for(CartItem item: cart.getCartItems()) {
			OrderItem oderItem = new OrderItem();
			
			oderItem.setPrice(item.getPrice());
			oderItem.setProduct(item.getProduct());
			oderItem.setQuantity(item.getQuantity());
			oderItem.setSize(item.getSize());
			oderItem.setUserId(item.getUserId());
			oderItem.setDiscountedPrice(item.getDiscountedPrice());
			
			OrderItem createdOderItem = orderItemRepository.save(oderItem);
			
			orderItems.add(createdOderItem);
			
		}
		
		Order createdOrder = new Order();
		
		createdOrder.setUser(user);
		createdOrder.setOrderItems(orderItems);
		createdOrder.setTotalPrice(cart.getTotalPrice());
		createdOrder.setTotalDiscountedPrice(cart.getTotalDiscountedPrice());
		createdOrder.setDiscount(cart.getDiscount());
		createdOrder.setTotalItem(cart.getTotalItem());
		createdOrder.setShippingAddress(address);
		createdOrder.setOrderDate(LocalDateTime.now());
		createdOrder.setOrderStatus("PENDING");
		createdOrder.getPaymentDetails().setStatus("PENDING");
		createdOrder.setCreatedAt(LocalDateTime.now());
		
		Order savedOrder = orderRepository.save(createdOrder);
		
		for(OrderItem item:orderItems) {
			item.setOrder(savedOrder);
			orderItemRepository.save(item);
		}
		
		return savedOrder;
	}

	@Override
	public Order placedOrder(Long orderId) throws OrderException {
		
		Order order = findOrderById(orderId);
		order.setOrderStatus("PLACED");
		order.getPaymentDetails().setStatus("COMPLETED");
		return order;
	}

	@Override
	public Order confirmedOrder(Long orderId) throws OrderException {
		
		Order order = findOrderById(orderId);
		order.setOrderStatus("CONFIRMED");
		
		return orderRepository.save(order);
	}

	@Override
	public Order shippedOrder(Long orderId) throws OrderException {
		
		Order order = findOrderById(orderId);
		order.setOrderStatus("SHIPPED");
		
		return orderRepository.save(order);
	}

	@Override
	public Order deliveredOrder(Long orderId) throws OrderException {
		
		Order order = findOrderById(orderId);
		order.setOrderStatus("SHIPPED");
		return null;
	}

	@Override
	public Order canceledOrder(Long orderId) throws OrderException {
		
		Order order = findOrderById(orderId);
		order.setOrderStatus("CANCELED");
		
		return orderRepository.save(order);
	}
	
	@Override
	public Order findOrderById(Long orderId) throws OrderException {
		
		Optional <Order> opt = orderRepository.findById(orderId);
		
		if(opt.isPresent()) {
			return opt.get();
			}
		throw new OrderException("Order does not exist with id " + orderId);
	}
	
	@Override
	public List<Order> usersOrderHistory(Long userId) {
		
		List<Order> orders = orderRepository.getUsersOrders(userId);
		return orders;
	}
	
	@Override
	public List<Order> getAllOrders() {
		
		return orderRepository.findAll();
		
	}
	
	@Override
	public void deleteOrder(Long orderId) throws OrderException {
		
		Order order = findOrderById(orderId);
		
		orderRepository.deleteById(orderId);
		
	}
	
	 

}
