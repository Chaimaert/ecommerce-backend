package com.chaimae.service;

import com.chaimae.exception.UserException;
import com.chaimae.model.User;

public interface UserService {
	
	public User findUserById(long userId) throws UserException;
	
	public User findUserProfileByJwt(String jwt) throws UserException;

}
