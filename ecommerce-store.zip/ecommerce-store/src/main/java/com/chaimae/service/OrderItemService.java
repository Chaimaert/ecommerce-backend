package com.chaimae.service;

import com.chaimae.model.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderItem(OrderItem orderItem);

}
