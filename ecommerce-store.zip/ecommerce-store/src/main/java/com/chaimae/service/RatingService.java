package com.chaimae.service;

import java.util.List;

import com.chaimae.exception.ProductException;
import com.chaimae.model.Rating;
import com.chaimae.model.User;
import com.chaimae.request.RatingRequest;

public interface RatingService {
	
	public Rating createRating(RatingRequest req, User user) throws ProductException;
	public List<Rating> getProductsRating(Long productId);

}
