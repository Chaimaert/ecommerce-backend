package com.chaimae.service;

import java.util.List;

import com.chaimae.exception.ProductException;
import com.chaimae.model.Review;
import com.chaimae.model.User;
import com.chaimae.request.ReviewRequest;

public interface ReviewService {
	
	public Review createReview(ReviewRequest req, User user) throws ProductException;
	public List<Review> getAllReview(Long productId);

}
