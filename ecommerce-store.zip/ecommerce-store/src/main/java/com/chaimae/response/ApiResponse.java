package com.chaimae.response;

import lombok.Data;

@Data
public class ApiResponse {
    private String message;
    private Boolean status;

    public ApiResponse(String message, Boolean status) {
        this.message = message;
        this.status = status;
    }

    // Default constructor
    public ApiResponse() {
    }

    // Setter for message
    public void setMessage(String message) {
        this.message = message;
    }

    // Setter for status
    public void setStatus(Boolean status) {
        this.status = status;
    }
}
